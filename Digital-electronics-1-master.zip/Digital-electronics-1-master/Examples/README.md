# Examples

* [Basic gates](https://www.edaplayground.com/x/5L92)
* [Clock enable circuit](https://www.edaplayground.com/x/5LiJ)
* [N-bit Up/Down binary counter](https://www.edaplayground.com/x/5bgq)
* [Driver for 7-segment display](https://www.edaplayground.com/x/3f_A)
* [One-minute stopwatch](https://www.edaplayground.com/x/2uKg)
* [Traffic light controller](https://www.edaplayground.com/x/5HBi)
